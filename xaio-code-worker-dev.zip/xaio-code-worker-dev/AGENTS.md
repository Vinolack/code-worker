# PROJECT KNOWLEDGE BASE

**Generated:** 2026-01-21 09:37:12 UTC
**Commit:** 453efda
**Branch:** dev

## OVERVIEW
High-performance FastAPI-based VLM (Vision Language Model) proxy service. Routes AI requests (Chat, TTS, Audio, Images) to upstream providers with model aliasing, transformation logic, and automated usage tracking.

## STRUCTURE
```
.
├── main.py                 # Execution entry point (uvicorn)
├── src/
│   ├── server.py           # App factory & lifecycle management
│   ├── base/               # Foundation: logging, exceptions, redis client
│   ├── dao/                # Data Access: Redis managers (logs, config)
│   ├── services/           # Business Logic: VLM proxying, model resolution
│   ├── routers/            # API Endpoints: VLM & Chat App routes
│   ├── jobs/               # Background Jobs: Sync config/keys, report logs
│   └── utils/              # Tech Utilities: SSE client, token counting
├── tests/                  # Integration & Functional tests
└── config.example.toml     # Configuration template
```

## WHERE TO LOOK
| Task | Location | Notes |
|------|----------|-------|
| Proxy Logic | `src/services/vlm.py` | Handles Chat, TTS, Audio, Images |
| Model Config | `src/jobs/ai_model.py` | Syncs encrypted configs from upstream |
| Network Driver | `src/utils/sse_proxy_client.py` | SSE heartbeats & stream generation |
| Logging Flow | `src/jobs/chat_log.py` | Batch reports usage from Redis to upstream |
| Auth Patterns | `src/routers/depends.py` | API key extraction & validation |

## CODE MAP
| Symbol | Type | Location | Refs | Role |
|--------|------|----------|------|------|
| `VlmService` | Class | `src/services/vlm.py` | High | Central proxy orchestrator |
| `SseProxyClient` | Class | `src/utils/sse_proxy_client.py` | Med | SSE keep-alive network client |
| `TraceUtil` | Class | `src/base/utils/trace_util.py` | High | Tracing & context management |
| `ChatLogRedisManager`| Class | `src/dao/redis/managers/chat_log.py`| Med | Usage log queue management |
| `BaseAPIRouter` | Class | `src/routers/base.py` | High | Automatic logging for all endpoints |

## CONVENTIONS
- **Tracing**: Every request MUST have `req_id` and `trace_id` (propagated via `contextvars`).
- **Model Aliasing**: Clients use aliases; service resolves to `real_ai_model` via Redis.
- **Transformation**: Use `need_transform=1` for intermediate protocol rewriting.
- **Response Shape**: All API responses wrap in generic `R[T]` (code, message, data).
- **Non-blocking Logs**: Log processing occurs in background callbacks to avoid client latency.

## ANTI-PATTERNS (THIS PROJECT)
- **Direct Body Assignment**: Deprecated in `aiohttp` contexts; use proper payload wrappers.
- **Unbounded Images**: Never bypass the `BoundedSemaphore(2)` for image generation.
- **Raw Provider Names**: Clients should never hit `real_ai_model` directly in production.
- **Blocking I/O**: Avoid synchronous network/disk calls; use the provided async drivers.

## UNIQUE STYLES
- **Service-DAO Pattern**: Explicit separation of business logic and Redis data access.
- **Hybrid Source**: Stub/test routers occasionally found in `src/routers/` (e.g., `vlm_test.py`).
- **TOML Config**: Centralized configuration via `config.toml` (not `.env`).

## COMMANDS
```bash
# Start service
python main.py

# Run tests
pytest

# Docker Build
docker build -t xaio-coder-worker .
```

## NOTES
- **Redis Requirement**: Application will fail to start if Redis connection is unavailable.
- **Upstream Sync**: API keys and models are periodically synced from an external manager; local edits to Redis may be overwritten.
