# AGENTS.md - src/routers

## OVERVIEW
This directory serves as the API layer for the worker service. It defines the entry points for all AI-related proxy requests and internal application endpoints. The primary responsibility of these "agents" is to handle HTTP-level concerns: routing, authentication dependency injection, and request/response lifecycle management.

## STRUCTURE
- **`base.py`**: The foundation for all routers. It contains `BaseAPIRouter`, which configures routes to use `LoggingAPIRoute`.
- **`vlm.py`**: The main proxy hub. It handles OpenAI-compatible endpoints like `/v1/chat/completions`, as well as audio, image, and rerank requests.
- **`chat_app.py`**: Provides higher-level endpoints for specific chat application features, abstracting multiple service calls.
- **`health.py`**: Standard monitoring endpoints for service availability.

## WHERE TO LOOK
- **Logging Implementation**: `src/middlewares/api_route.py` contains the `LoggingAPIRoute` logic injected via `BaseAPIRouter`.
- **Authentication Hook**: `src/routers/vlm.py` defines `get_api_key`, the shared dependency for extracting Bearer tokens.
- **Service Integration**: Most routes delegate to `src/services/vlm.py` or `src/services/chat_app.py` to keep the router logic minimal.

## CONVENTIONS
- **Automatic Logging**: Inherit from `BaseAPIRouter` to ensure every request is automatically traced with performance metrics and payload logging via `LoggingAPIRoute`.
- **Auth Dependency**: Use `api_key: str = Depends(get_api_key)` for any endpoint requiring a user token.
- **Standardized Errors**: Raise `HttpException` (from `src.base.exceptions`) to ensure errors are caught by the global error handler and returned in a consistent JSON format.
- **Streaming Patterns**: When handling SSE (Server-Sent Events), the router must return a `StreamingResponse` and manage error propagation from the service generator.

## ANTI-PATTERNS
- **Ignoring BaseAPIRouter**: Using the standard `fastapi.APIRouter` is discouraged as it bypasses the automatic request logging required for debugging and metrics.
- **Inline Logic**: Avoid writing business logic, model transformations, or direct Redis calls inside the route functions.
- **Manual Loggers**: Do not use `logger.info` to log incoming request bodies; this is already handled by the `LoggingAPIRoute` middleware.
- **Hardcoded Prefixes**: Use the `prefix` parameter in the router constructor instead of hardcoding paths in every decorator.
