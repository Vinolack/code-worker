# src/jobs: Background Task Management

## OVERVIEW
The `src/jobs` directory handles all background operations using **APScheduler** (`AsyncIOScheduler`). It maintains the worker's operational state by ensuring configuration parity with upstream services and providing reliable log reporting.

**Key Responsibility**: Asynchronous synchronization of API keys and model configurations from the upstream management service to the local Redis cache.

## STRUCTURE
- **scheduler.py**: The central `SchedulerManager` (singleton) that orchestrates job registration, startup, and shutdown.
- **api_key.py**: Implements `SyncApiKeysJob` to periodically refresh the list of authorized worker API keys.
- **ai_model.py**: Implements `SyncAiModelJob` to fetch model aliases, decrypt sensitive credentials, and update the Redis model set.
- **chat_log.py**: Manages `SyncChatLogJob` for dual-queue usage reporting (Main Queue + Dead Letter Queue retry logic).
- **except_log.py**: Manages `SyncExceptLogJob` for reporting system exceptions and errors.

## WHERE TO LOOK
- **Job Registration**: Check `SchedulerManager._register_jobs()` in `scheduler.py` to see active jobs and their intervals.
- **Sync Logic**: Look at `SyncAiModelJob.sync_ai_model` and `SyncApiKeysJob.sync_api_keys` for upstream integration details.
- **Error Recovery**: Review `SyncChatLogJob.task_retry_dlq` for how failed log reports are handled.

## CONVENTIONS
- **Async First**: All jobs MUST be `async` methods to avoid blocking the `AsyncIOScheduler` event loop.
- **Self-Contained**: Jobs should handle their own exceptions internally to prevent a single failure from crashing the scheduler.
- **Configuration Driven**: Use `src.config` to manage intervals and enable/disable specific jobs (e.g., `CHAT_LOG_ENABLE`).
- **Initial Sync**: Critical jobs (API keys/models) are executed once immediately upon scheduler start before the interval timer begins.

## ANTI-PATTERNS
- **Blocking I/O**: Never use `requests` or synchronous database calls; use `httpx.AsyncClient` or async DB drivers.
- **Hardcoded Intervals**: Avoid hardcoding time intervals; always reference the central `config` object.
- **Direct Redis Overwrites**: Use atomic operations or temp-key-then-rename patterns (as seen in `ai_model.py`) when updating large configuration sets.
- **Infinite Loops**: Do not implement `while True` loops inside jobs; rely on the scheduler's `interval` trigger.
