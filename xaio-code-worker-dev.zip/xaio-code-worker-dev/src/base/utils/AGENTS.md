# AGENTS.md - src/base/utils

## OVERVIEW
Central utility hub providing core primitives for tracing, context management, cryptography, and common helper functions.

## STRUCTURE
.
├── context_util.py      # Low-level contextvars definitions
├── crypto_util.py       # Fernet-based symmetric encryption
├── func_util.py         # Miscellaneous functional helpers
├── trace_util.py        # High-level tracing API (preferred over context_util)
├── uuid_util.py         # UUID and random string generation
└── web.py               # API response standardization

## WHERE TO LOOK
- **Tracing & Context Management**: `trace_util.py` and `context_util.py` are the primary files for request lifecycle tracking and async context propagation.
- **Security & Cryptography**: `crypto_util.py` provides symmetric encryption (Fernet) for sensitive configurations like API keys and tokens.
- **Identifiers**: `uuid_util.py` contains logic for standardized UUIDv4 (hex format) and random string generation with entropy expansion.
- **Web Helpers**: `web.py` manages standardized API response structures for error conditions, ensuring consistent JSON output.
- **Functional Helpers**: `func_util.py` contains small utility functions like list chunking and conditional parameter mapping for dictionary building.

## CONVENTIONS
- **Async Safety via contextvars**: This project strictly uses Python's `contextvars` module to propagate request-specific state across asynchronous tasks. This ensures that `REQUEST_ID` and `TRACE_ID` remain isolated per execution task even when using `asyncio.gather()` or background tasks.
- **Context Variables**: 
  - `REQUEST_CTX`: Stores the current FastAPI `Request` object.
  - `REQUEST_ID`: Stores the unique ID for the current HTTP request (prefixed with `req-id:`).
  - `TRACE_ID`: Stores a broader tracking ID for background jobs or internal workflows (prefixed with `trace-id:`).
- **Propagation Hook**: Trace IDs should be initialized early in the request lifecycle (typically in `TraceReqMiddleware`) using `TraceUtil.set_req_id()`.
- **Trace Access**: Components should retrieve the current request context using `TraceUtil.get_req_id()` instead of passing IDs through multiple function layers.
- **Context Injection**: The `REQUEST_CTX` is populated via FastAPI dependencies (`src/middlewares/depends.py`) to make the current `Request` object accessible globally within the async execution context.
- **Standardized Responses**: All non-success API responses should be routed through `web.fail_api_resp_*` functions to maintain consistent JSON schemas.

## ANTI-PATTERNS
- **Manual contextvars Access**: Avoid calling `.get()` or `.set()` directly on `ContextVar` instances in `context_util.py`. Always use the static methods provided by `TraceUtil`.
- **Thread Local Storage**: Never use `threading.local()` or global variables for request data; they do not persist correctly across `await` points in `asyncio` and will leak between requests.
- **Inconsistent ID Formats**: Do not generate raw UUIDs for tracing manually; `TraceUtil` ensures IDs are prefixed correctly for logging clarity and filtering.
- **Hardcoded Error Codes**: Avoid defining error codes inline; use the enums and helper functions in `web.py` to ensure consistency with the frontend and API documentation.
- **Direct cryptography Usage**: Use `CryptoUtil` for encryption tasks rather than importing `cryptography` directly in business logic to ensure consistent key handling and error management.
