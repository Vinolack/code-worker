# AGENTS.md - src/base

## OVERVIEW
The foundation layer of the application. This directory provides the core infrastructure, including logging, exception handling, Redis connectivity, and low-level utilities. It serves as the primary source of truth and base for all other modules in `src`.

## STRUCTURE
- **logging/**: Loguru-based tracing and configuration. Centralizes all application logs with support for rotation and retention.
- **exceptions/**: Standardized exception hierarchy (`BizException`, `HttpException`). Ensures consistent error reporting across the service.
- **redis/**: `BaseRedisManager` for managing shared synchronous and asynchronous Redis client connections.
- **enums/ & constants/**: Source of truth for error codes (`BaseErrCodeEnum`) and global constant values.
- **utils/**: Foundational utilities like `TraceUtil` for request/trace ID management and `ContextUtil` for context propagation.

## WHERE TO LOOK
- **Request Tracking**: `src/base/utils/trace_util.py` manages `req_id` and `trace_id`, which are essential for debugging distributed requests.
- **Error Definitions**: `src/base/enums/error.py` contains the authoritative list of error codes used by `HttpException`.
- **Logging Setup**: `src/base/logging/base.py` initializes the Loguru sinks and formatting.
- **Redis Initialization**: `src/base/redis/redis_client.py` provides the singleton-like client management logic.

## CONVENTIONS
- **Foundation Priority**: Always prefer using `src.base` implementations over external libraries or custom local reimplementations.
- **Trace Awareness**: Use `TraceUtil` to propagate request contexts across different layers of the application.
- **Standardized Exceptions**: Always raise `HttpException` or `BizException` with appropriate `BaseErrCodeEnum` values.
- **Async/Sync Redis**: Specify `async_client=True` in `init_redis_client` when working within FastAPI's async context.

## ANTI-PATTERNS
- **Circular Dependencies**: Do not import from higher-level modules (`src/services`, `src/routers`) into `src/base`.
- **Direct Loguru Calls**: Avoid calling `logger.add()` outside of `src/base/logging/base.py`.
- **Hardcoded Error Messages**: Use `BaseErrCodeEnum` instead of hardcoding error strings or codes in business logic.
- **Raw Redis Clients**: Do not instantiate `redis.Redis` directly; use `BaseRedisManager` to ensure connection pooling.
- **Bypassing Trace IDs**: Never log critical request information without including or setting the `trace_id` via `TraceUtil`.
