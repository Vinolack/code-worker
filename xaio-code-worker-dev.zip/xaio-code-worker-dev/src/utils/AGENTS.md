# AGENTS.md - Networking & Utilities

## OVERVIEW
This directory houses the mission-critical networking stack of the AI proxy. These utilities manage high-concurrency connections to upstream providers, ensuring robustness through sophisticated retry mechanisms and real-time stream stability. It is the "engine room" for all model interactions.

## STRUCTURE
- **`http_client.py`**: The foundation. Implements `AsyncHttpClient` using a worker-queue pattern. It decouples upstream fetching from downstream consumption, allowing the worker to continue gathering stats even if a client disconnects.
- **`sse_proxy_client.py`**: Specialization for Server-Sent Events. Adds a layer of "heartbeat injection" to prevent intermediate proxies (like Nginx or Cloudflare) from dropping idle connections during long LLM generations.

## WHERE TO LOOK
- **`stream_generator_with_heartbeat`**: Look here to see how `asyncio.shield` and `wait_for` are combined to multiplex actual data chunks with periodic keep-alive comments (heartbeats).
- **`_worker` Loop**: The complex state machine in `AsyncHttpClient` handling `auth_errors` vs `normal_retry_errors`, exponential backoff, and TTFT (Time To First Token) callback triggers.
- **`RequestContext`**: The central state object tracking `startup_future` (connection established) and `result_future` (total request finished).

## CONVENTIONS
- **Stat Integrity**: The system prioritizes accurate logging. Workers MUST NOT be killed immediately upon client disconnect; they must finish reading from upstream to record total token usage.
- **Sentinel Pattern**: Use `ctx.sentinel` in queues to signal clean stream termination to the generator.
- **Async Safety**: All callbacks (`on_success`, `on_failure`) are executed safely via `run_in_executor` or `create_task` to prevent blocking the main network loop.

## ANTI-PATTERNS
- **Raw `aiohttp` Usage**: Never use `aiohttp` directly in services. Always route through `SseProxyClient` to benefit from the centralized pooling and retry logic.
- **Blocking the Queue**: Avoid `stream_queue.put()` if `consumer_disconnected` is true, as it can cause the worker to hang indefinitely if the queue is full and no one is reading.
- **Hard-coded Timeouts**: Do not hard-code timeouts in service logic; use the `RequestWrapper` configuration which integrates with the global deadline management.
