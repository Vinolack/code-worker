# AGENTS.md - API Models Protocol

## OVERVIEW
This directory contains the Pydantic schemas defining the interface between the worker, clients, and upstream AI providers. It ensures strict data validation, OpenAI compatibility, and standardized internal communication.

## STRUCTURE
- `vlm/`: Core VLM protocols (Chat, Audio, Embeddings). Follows OpenAI's API specification.
- `comm/`: Common response wrappers (`R`, `CommPageResp`) for unified internal API responses.
- `chat_app/`: High-level application models for the integrated chat interface.
- `except_log/`: Models for exception tracking and logging payloads.

## WHERE TO LOOK
- `vlm/protocol.py`: Defines `OpenAIBaseModel`, the foundation for all OpenAI-compatible schemas.
- `comm/CommResp.py`: Defines the generic `R[T]` wrapper used for standardized JSON responses.

## CONVENTIONS
- **Forward Compatibility**: All OpenAI-compatible models MUST use `model_config = ConfigDict(extra="allow")`. This prevents crashes when upstream providers introduce new response fields.
- **Strict Typing**: Use `Literal`, `Union`, and `TypeAlias` (from `typing_extensions`) to match official API specs exactly.
- **Documentation**: Use `Field(..., description="...")` or docstrings for every field to enable clear OpenAPI (Swagger) documentation.
- **Validation**: Use `@model_validator` or `@field_validator` for complex cross-field dependencies (e.g., `stream_options` requiring `stream=True`).

## ANTI-PATTERNS
- **Extra Forbid**: NEVER use `extra="forbid"` for models that map to external API responses.
- **Manual JSON Parsing**: Avoid manual dictionary manipulation; rely on Pydantic's `model_validate` and `model_dump`.
- **Hardcoded Codes**: Do not hardcode error codes; use `BaseErrCodeEnum` or `HTTPStatus`.
- **Root Repetition**: Do not duplicate core business logic; keep this layer focused strictly on data shape and validation.
