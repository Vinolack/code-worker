# AGENTS.md - src

## OVERVIEW
The `src` directory is the core of the **xaio-coder-worker**, containing the entire business logic and proxy engine. It is highly complex because it handles real-time AI request routing, streaming transformations, and asynchronous usage logging across a distributed architecture.

## STRUCTURE
The project follows a strict **4-Layer Architecture** flow to ensure separation of concerns:

1.  **Routers (`routers/`)**: The entry point. Handles FastAPI routes, authentication dependencies, and request/response lifecycle.
2.  **Services (`services/`)**: The orchestrator. Implements core logic (e.g., `VlmService`), manages upstream connections, and triggers logging callbacks.
3.  **DAO (`dao/`)**: Data Access Objects. Manages specific data stores (primarily Redis) for caching model configurations and queuing chat logs.
4.  **Base (`base/`)**: The foundation. Provides low-level utilities, custom exceptions, logging configuration, and core Redis client wrappers.

**Request Flow:** `Client` → `Router` → `Service` → `DAO/Base` → `Upstream AI Provider` → (back through layers with callbacks).

## WHERE TO LOOK
-   **API Entry Points**: Check `routers/vlm.py` for proxy endpoints and `routers/chat_app.py` for feature-specific APIs.
-   **Core Proxy Engine**: `services/vlm.py` contains the 1500+ line logic for model aliasing, transformation, and request handling.
-   **Data Management**: `dao/redis/managers/` for specific Redis-backed data operations.
-   **System Foundation**: `base/utils/` for trace ID tracking and `base/exceptions/` for standard error handling.
-   **Background Tasks**: `jobs/` directory contains scheduled synchronization tasks (API keys, models, logs).

## CONVENTIONS
-   **Dependency Direction**: Higher layers (`routers`) can call lower layers (`services`, `dao`), but lower layers should never call higher layers.
-   **Async First**: All I/O-bound operations (AI requests, Redis calls) must be `async`.
-   **Traceability**: Use `TraceUtil` and `logger` from `src.base` to ensure every request is trackable via `trace_id`.
-   **Standardized Responses**: Always return `CommResp` or `JSONResponse` using models from `api_models`.
-   **Explicit Callbacks**: Attach `_request_success_callback` to every `RequestWrapper` in services to ensure usage is billed/logged.

## ANTI-PATTERNS
-   **Layer Skipping**: Do not call `RedisManager` or raw `aiohttp` directly from a `Router`. Use a `Service`.
-   **Business Logic in Routers**: Keep routes thin. If it's more than orchestration or validation, it belongs in a `Service`.
-   **Raw Loggers**: Use the project's configured `logger` from `src.base.logging` rather than the standard library `logging`.
-   **Blocking synchronous code**: Never use `time.sleep()` or synchronous `requests` inside this async-first codebase.
