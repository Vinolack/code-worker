# AGENTS.md - src/services

## OVERVIEW
Core business logic directory handling VLM proxying, chat applications, and logging services.

## STRUCTURE
- **vlm.py**: Primary service (1500+ lines) implementing proxy logic for Chat, TTS, Images, Audio, Rerank, and Embeddings. It is the heart of the proxy engine.
- **chat_app.py**: High-level chat application business logic and orchestration, including user-facing chat management.
- **chat_log.py** / **except_log.py**: Specialized services for recording usage metrics and system exceptions to Redis for later synchronization.
- **api_key.py**: Logic for API key lifecycle management, validation, and interaction with upstream authentication services.

## WHERE TO LOOK
- **Model Aliasing**: `VlmService._build_final_url_and_headers` resolves client-facing model names to backend configurations via Redis (`USER_AI_MODEL_SET_PREFIX`).
- **Transformation Logic**: `VlmService._build_final_url_and_headers` handles `need_transform=1` by rewriting URLs to `transform_base_url` and injecting upstream headers for worker-to-worker routing.
- **Token Tracking**: `VlmService._request_success_callback` and `_request_success_callback_stream` extract `usage` data (prompt/completion tokens) for billing and reporting.
- **Request Wrapping**: All AI calls are wrapped in `RequestWrapper` (from `http_client.py`) with attached success/error callbacks for reliable execution and logging.
- **Service Lifespan**: `VlmService.startup()` and `shutdown()` manage the lifecycle of the shared `SseProxyClient`.

## CONVENTIONS
- **Async Implementation**: All service methods must be `async` to avoid blocking the FastAPI event loop.
- **Shared Client**: Use the shared `SseProxyClient` instance managed by `VlmService` for all upstream requests.
- **Standardized Logging**: Always attach `_request_success_callback` to ensure usage logs are queued in Redis.
- **Exception Handling**: Raise `HttpException` from `src.base.exceptions` for consistent API error responses.

## ANTI-PATTERNS
- **Raw HTTP Calls**: Never use `requests` or direct `aiohttp.ClientSession`. Use the `SseProxyClient` wrapper.
- **Hardcoded Models**: Do not hardcode model IDs or provider URLs; rely on the Redis-based model configuration system.
- **Missing Callbacks**: Initiating a request without usage tracking callbacks leads to unbilled consumption.
- **Blocking Logic**: Avoid heavy synchronous processing; use background tasks for non-critical logging.
- **Ignoring Concurrency Limits**: Resource-intensive tasks (like Image Generation) must respect `BoundedSemaphore(2)` limits defined in the service.
- **Bypassing SseProxyClient**: The client handles request queuing, retries, and SSE parsing; bypassing it breaks these core features.
